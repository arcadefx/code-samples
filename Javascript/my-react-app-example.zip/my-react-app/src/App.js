import React from 'react';
import logo from './logo.svg';
import headProfile from './HeadProfile.svg';
import './App.css';
import FavoriteActivity from './components/favortieActivity';
import { sample } from 'lodash';

class App extends React.Component {

  constructor (props) {
    super(props);
    this.state = {
      counter: props.commonProps.defaultCounter,
      loading: true
    }
  }

  async componentDidMount() {
    const url = 'https://api.randomuser.me/?results=8';
    const response = await fetch(url);
    const data = await response.json();
    this.setState({ people: data.results, loading: false });
  }

  pickRandomUser() {
    this.setState({ counter: this.state.counter + 1 });
    this.setState({ user: sample(this.state.people) });
  }

  header() {
    return (
        <div>
          <img src={logo} className="App-logo" alt="logo" />
        </div>
    );
  }

  people() {
    if (this.state.people) {
      return (
        <div>
          <h3>Random User Listing<div className="randomUsers">Supplied by: https://api.randomuser.me</div></h3>
          {
              this.state.people.map((person, i) => (
              <div key={`people-${i}`} className="people-list">
                <div>
                  { person.name.title } { person.name.first } { person.name.last }
                </div>
              </div>
            ))
          }
        </div>
      );
    } else {
      return (
        <div className="people-list">{ this.state.loading ? <div>loading...</div> : <div>no people</div>}</div>
      );
    }
  }


  showRandomPerson() {
    if (this.state.user) {
      return (
        <div className="randomPersonInfo">
          <img src={ this.state.user.picture.large } alt="random person" />
          <div>{ this.state.user.name.first }</div>
          <FavoriteActivity favorite="Ride Bike" />
        </div>
      );
    } else {
      return (
        <div className="randomPersonInfo">
          <img src={ headProfile } className="smallHead" alt="no person" />
          <p>Mr Random</p>
        </div>
      );
    }
  }

  render () {
    return (
      <div className="App">
        <header className="App-header">
          { this.header() }
          <div className="people-container">
            <div className="randomPerson">
              { this.showRandomPerson() }
            </div>
            { this.people() }
          </div>
          <div>
            <button onClick={ this.pickRandomUser.bind(this) }>Pick Random User</button>
          </div>
          <p>Pick counter: { this.state.counter }</p>
        </header>
      </div>
    );
  }
}

export default App;

