import React from 'react';

class FavoriteActivity extends React.Component {

    constructor (props) {
      super(props);
      this.state = {
        fav: props.favorite
      }
    }
  
    render() {
      return (
        <div className="favActivity">Activity: { this.state.fav }</div>
      )
    }
}

export default FavoriteActivity;
