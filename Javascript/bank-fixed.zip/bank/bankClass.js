

class Bank {
    constructor(name) {
        this.name = name;
        this.accounts = new Map();
    }

    NewAccount(parameters) {
        if (parameters.accountType === 'Checking') {
            this.accounts.set(parameters.accountHolder, new CheckingAccount(parameters));
        } else {
            this.accounts.set(parameters.accountHolder, new SavingsAccount(parameters));
        }
    }

    GetAccount(name) {
        return this.accounts.get(name);
    }

    Banner() {
        return `Welcome to ${this.name}`;
    }
}

class Account {
    constructor(parameters) {
        if (this.constructor === Account) {
                throw new Error('Cannot instantiate abstract class transaction');
        }
        this.accountType = parameters.accountType;
        this.accountHolder = parameters.accountHolder;
        this.balance = parameters.balance;
    }

    Deposit(amount) {
        this.balance += amount;
        this.receipt = `You have deposited ${amount} into account ${this.accountHolder}`;
    }

    Withdraw(amount) {
        if (this.checkingType === 'Individual' && amount >= 1000) {
            this.receipt = `You have a limit of $1000 on withdraw.`;
        } else {
            this.balance -= amount;
            this.receipt = `You have withdrawn ${amount} from account ${this.accountHolder}`;
        }
    }

    Transfer(amount, accountTo) {
        this.balance -= amount;
        accountTo.balance += amount;
        this.receipt = `You have transferred ${amount} from account ${this.accountHolder}`;
        this.receipt += ` to account ${accountTo.accountHolder}`;
    }
}

class CheckingAccount extends Account {
    constructor(parameters) {
        parameters.accountType = 'Checking'
        parameters.checkingType = 'Individual';
        super(parameters);
    }
}

class SavingsAccount extends Account {
    constructor(parameters) {
        parameters.accountType = 'Checking'
        parameters.checkingType = 'Money Market';
        super(parameters);
    }
}

const _moneyFormatter = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
});

module.exports = {
    Bank
};
