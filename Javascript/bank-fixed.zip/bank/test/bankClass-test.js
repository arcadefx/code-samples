const expect = require('chai').expect;
const sinon = require('sinon');
const mockery = require('mockery');
const Bank = require('../bankClass').Bank;

let myBank;

describe('Bank module tests', () => {

    before(() => {
        mockery.disable();
        mockery.deregisterAll();
        mockery.enable({ useCleanCache: true, warnOnUnregistered: false });

        myBank = new Bank('Demo Bank');

        myBank.NewAccount({
            accountType: 'Checking',
            accountHolder: 'Johnny Apple',
            balance: 0
        });

        myBank.NewAccount({
            accountType: 'Checking',
            accountHolder: 'Miss Orange',
            balance: 0
        });

    });

    after('cleanup', () => {
        mockery.disable();
        mockery.deregisterAll();
    });

    describe('Deposit', () => {
        it('should deposit 500', () => {
            let account = myBank.GetAccount('Johnny Apple');
            account.Deposit(500);
            expect(account.balance).to.eql(500);
        });
    });

    describe('Withdraw', () => {
        it('should withdraw 50', () => {
            let account = myBank.GetAccount('Johnny Apple');
            account.Withdraw(50);
            expect(account.balance).to.eql(450);

        });
    });

    describe('Transfer', () => {
        it('should transfer 50', () => {
            let account = myBank.GetAccount('Johnny Apple');
            let account2 = myBank.GetAccount('Miss Orange');
            account.Transfer(50, account2);
            expect(account.balance).to.eql(400);
            expect(account2.balance).to.eql(50);
        });
    });
});
