'use strict';

const messageController = require('../controllers/message.controller');

module.exports = (app) => {
    app.get('/', (req,res) => {
        res.sendFile(process.cwd()+"/dist/my-app/index.html");
    });
    app.get('/api/search', messageController.searchMessages);
    app.get('/search', messageController.searchMessages);
};
