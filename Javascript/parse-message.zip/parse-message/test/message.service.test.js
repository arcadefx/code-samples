const expect = require('chai').expect;
const messageService = require('../services/message.service');
const _ = require('lodash');


describe('Message parsing module tests', () => {
    let messages;

    beforeEach(() => {
        messages = _.cloneDeep(messageService.messages)
    });
    afterEach(() => {
        messageService.messages = _.cloneDeep(messages);
        messages = [];
    });

    describe('readMessages', () => {
        it('should return messages if queue is not empty', () => {
            messageService.messages = [ 'NAM|FNABob|LNAGuy||' ];
            const result = messageService.readMessages();
            const expectedResult = [ {
                'NAM': {
                    'FNA': 'Bob',
                    'LNA': 'Guy'
                }
            } ];

            expect(result).to.eql(expectedResult);
        });

        it('should not return messages if queue is empty', () => {
            messageService.messages = [ ];
            const result = messageService.readMessages({ bustCache: true });
            const expectedResult = [ ];

            expect(result).to.eql(expectedResult);
        });

        it('should return messages not from cache if cache is busted', () => {
            messageService.messages = ['NAM|FNABob|LNAGuy||' ];
            messageService.readMessages({ bustCache: true });
            messageService.messages = ['NAM|FNASome|LNADeveloper||' ];
            const result = messageService.readMessages({ bustCache: true });
            const expectedResult = [ {
                'NAM': {
                    'FNA': 'Some',
                    'LNA': 'Developer'
                }
            } ];

            expect(result).to.eql(expectedResult);
        });
    });

    describe('parseMessage', () => {
        it('should parse the message if message is passed', () => {
            const result = messageService.parseMessage('NAM|FNABob|LNAGuy||');
            const expectedResult = {
                'NAM': {
                    'FNA': 'Bob',
                    'LNA': 'Guy'
                }
            };
            expect(result).to.eql(expectedResult)
        });

        it('should not return a parsed message if no message is passed', () => {
            const result = messageService.parseMessage('');
            const expectedResult = { };
            expect(result).to.eql(expectedResult)
        });
    });

    describe('searchMessages', () => {
        it('should return the expected results when no parameters are passed', () => {
            messageService.rows = [];
            messageService.messages = [
                'NAM|FNABob|LNAGuy||',
                'NAM|FNADig|LNADug'
            ];
            const expectedResult = [ 
                {
                    'NAM': {
                        'FNA': 'Bob',
                        'LNA': 'Guy'
                    }
                },
                {
                    'NAM': {
                        'FNA': 'Dig',
                        'LNA': 'Dug'
                    }
                }
            ];
            return messageService.searchMessages().then((result) => {
                expect(result).to.eql(expectedResult);
            });
        });

        it('should return the expected results when valid parameters are passed', () => {
            messageService.rows = [];
            messageService.messages = [
                'NAM|FNABob|LNAGuy||',
                'NAM|FNADig|LNADug'
            ];
            const expectedResult = [ 
                {
                    'NAM': {
                        'FNA': 'Dig',
                        'LNA': 'Dug'
                    }
                }
            ];
            return messageService.searchMessages('nam', 'lna', 'dug').then((result) => {
                expect(result).to.eql(expectedResult);
            });
        });

        it('should return no results when search does not find anything', () => {
            messageService.rows = [];
            messageService.messages = [
                'NAM|FNABob|LNAGuy||',
                'NAM|FNADig|LNADug'
            ];
            const expectedResult = [ ];
            return messageService.searchMessages('nam', 'lna', 'cupcake').then((result) => {
                expect(result).to.eql(expectedResult);
            });
        });
    });

});
