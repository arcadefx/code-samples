'use strict';

const express = require('express');
const app = express();
const port = process.env.PORT || 3000;
const routes = require('./routes/server.routes');

app.use(express.static(process.cwd()+'/my-app/dist/my-app/'));

routes(app);

const server = app.listen(port, () => {
    console.log(`Server listening on the port::${port}`);
});
