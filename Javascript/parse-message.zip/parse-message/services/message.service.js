'use strict';

const isEmpty = require('lodash').isEmpty;

// cache
exports.rows = [];

// some data to use
exports.messages = [
    'NAM|FNAFred|LNABlogs||BIO|DOB02/03/1974||',
    'NAM|FNABob|LNAGuy||',
    'NAM|FNAMary|LNAJane||',
    'NAM|FNAPac|LNAMan||ARC|TYPRetro Game',
    'NAM|FNADonkey|LNAKong||ARC|TYPRetro Game',
    'NAM|FNAMine|LNACraft||ARC|TYPModern Game',
    'NAM|FNADonald|LNADuck||DIS|DWDDisney character',
    'NAM|FNAChip|LNAGuy||SPT|GAMFootball',
    'NAM|FNASome|LNAGuy||SPT|GAMBaseball',
    'NAM|FNASue|LNACool||SPT|GAMBaseball',
];

// Description: Below ingests the messages, re-organizes them into objects and stores them in a cache.
// The cache can be busted to read new entries.
// Notes: Typically a handler would be receiving messages from a message service, queue, bucket or
// device. 
//
exports.readMessages = (params = {}) => {
    if (params.bustCache) {
        exports.rows = [];
    }
    if (exports.rows.length) return exports.rows;

    exports.messages.forEach((message) => {
        const messageData = exports.parseMessage(message);
        if (Object.keys(messageData).length) {
            exports.rows.push(messageData);
        }
    });
    
    return exports.rows;
};

// Description: This extracts Segments, fields and values and builds a new object with the data.
// The new object is easier to maintain and perform lookups.
// Example input: NAM|FNAFred|LNABlogs||BIO|DOB02/03/1974||
//
exports.parseMessage = (message) => {
    const data = {};

    const segments = message.split('||');
    segments.forEach((segment) => {
        if (segment.length) {
            const record = segment.split('|');
            const segmentName = record.slice(0,1);

            // get and create the fields
            const fields = record.slice(1);
            const newEntry = {};
            fields.forEach((entry) => {
                const fieldName = entry.slice(0,3);
                const fieldData = entry.slice(3);
                newEntry[fieldName] = fieldData;
            });
            // store the segment entry
            data[segmentName] = newEntry;
        }
    });
    return data;
};

exports.searchMessages = (segment='', field='', term='') => {
    let result = [];

    // pagination if applicable would be used or a cursor
    const messages = exports.readMessages();
    const query = `${segment}${field}${term}`;
    if (!isEmpty(query) && (isEmpty(segment) || isEmpty(field) || isEmpty(term))) {
        return Promise.resolve([]);
    } else if (isEmpty(query)) {
        return Promise.resolve(messages);
    }
    segment = segment.toUpperCase();
    field = field.toUpperCase();
    messages.forEach((message) => {
        if (message[segment]) {
            const index = message[segment][field].toLowerCase().indexOf(term.toLowerCase());
            if (index !== -1) {
                result.push(message); 
            }
        }
    });
    return Promise.resolve(result);
};
