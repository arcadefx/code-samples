import { Component, OnInit } from '@angular/core';
import { HttpService } from './services/http.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'message-view-app';

  public assets = [];
  public searchSegment = '';
  public searchField = '';
  public searchValue = '';

  public hasShadow = false;

  constructor(private httpService: HttpService) {
    this.httpService = httpService;
  }

  ngOnInit(): void {
    this.searchMessages();
  }

  shadowToggle($event: any): void {
    this.hasShadow = $event.type === 'mouseover' ? true : false;
  }

  searchReset(): void {
    this.searchSegment = '';
    this.searchField = '';
    this.searchValue = '';
    this.searchMessages();
  }

  searchMessages(): void {
    const params = {
      segment: this.searchSegment,
      field: this.searchField,
      term: this.searchValue
    };
    this.httpService.sendGetRequest(params).subscribe((responseData: any) => {
      this.assets = responseData.length ? responseData : [];
    });
  }

  getKeys(asset): any {
    return Object.keys(asset);
  }

  getFields(asset, assetEntry): any[] {
    const result = [];
    const data = asset[assetEntry];
    for (const name of Object.keys(data)) {
        result.push({
          name,
          value: data[name]
        });
    }
    return result;
  }

  getSegmentCount(asset): number {
    return asset && Object.keys(asset).length || 0;
  }
}
