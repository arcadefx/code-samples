import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  public apiBaseUrlDev = ':3000/api/search';
  public apiBaseUrl = '';

  constructor(private httpClient: HttpClient) {
      this.apiBaseUrl = `http://${window.location.hostname}${this.apiBaseUrlDev}`;
  }

  sendGetRequest(params: any): Observable<object> {
    const query = `${this.apiBaseUrl}?segment=${params.segment}&field=${params.field}&term=${params.term}`;
    return this.httpClient.get(query);
  }
}
