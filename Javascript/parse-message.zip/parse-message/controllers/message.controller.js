'use strict';

const messageService = require('../services/message.service');
const _ = require('lodash');

exports.searchMessages = (req, res) => {
    const segment = req.query.segment || '';
    const field = req.query.field || '';
    const term = req.query.term || '';
    return messageService.searchMessages(segment, field, term).then((result) => {
        res.status(200).send(JSON.stringify(result));
    }).catch((err) => {
        const errorMsg = _.get(err, 'message', 'unknown error');
        console.log('oh snap!: ', errorMsg);
        res.status(500).send(JSON.stringify({ message: errorMsg }));
    });
};
