# parse-message app
A prototype of parsing messages written in NodeJS 13 and Angular 10 for frontend templating.

## How to install in local development environment

From the project root..

* `$ npm i`
* `$ cd my-app; npm i; cd ..`

## How to run in local development environment

From the project root..

`$ npm run start:dev`

Open Web Browser on port 3000 to view.


To see the JSON generate by the API call go to the following:
[API Query Example](http://localhost:3000/api/search?segment=&field=&term=)

## How to build for development

From the project root..

`$ npm run build:dev`

## How to test
This will test the module for parsing the messages only.

From the project root..

`$ npm run test`

For the client-side there are minimal tests and can be run by

`$ cd my-app`
`$ ng test`

## Basic code layout

### Server side code

The server-side code is located in the main repo directory. It is built with NodeJS 13. It is ES6 Javascript.

### Client side code

The client-side code is located in `my-app` directory. It is built with Angular 10 with TypeScript.

To apply changes to the Node side even with Node running do:

`$ ng build`

The server-side is monitoring the `my-app/dist` folder and will restart Node if updated.

### The client side build folder for distributing

The client side build folder for distributing is in `my-app/dist` directory.  It's is referenced in the NodeJS `routes/server.routes.js` for the root (/) path.

Note: If you compile the Angular 10 side and it will auto-restart the Node side.
