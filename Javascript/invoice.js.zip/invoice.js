const userSignedUp = [
    {
      id: 1,
      name: 'Employee #1',
      activatedOn: new Date('2018-11-04'),
      deactivatedOn: null,
      customerId: 1,
    },
    {
      id: 2,
      name: 'Employee #2',
      activatedOn: new Date('2018-12-04'),
      deactivatedOn: null,
      customerId: 2,
    },
    {
      id: 3,
      name: 'Employee #3',
      activatedOn: new Date('2019-01-10'),
      deactivatedOn: null,
      customerId: 3,
    },
  ];
  
  const constantUsers = [
    {
      id: 1,
      name: 'Employee #1',
      activatedOn: new Date('2018-12-04'),
      deactivatedOn: null,
      customerId: 1,
    },
    {
      id: 2,
      name: 'Employee #2',
      activatedOn: new Date('2018-12-04'),
      deactivatedOn: null,
      customerId: 2,
    },
  ];
  
  const newPlan = {
    id: 1,
    customerId: 1,
    monthlyPriceInDollars: 4,
  };
  
  const noUsers = [];

// get the dailyrate and cost per day and 

function billFor(month, activeSubscription, users) {
  // your code here!
  let monthTotal = 0;
  if (!month || !activeSubscription || !users.length) {
    return Number.parseFloat(monthTotal.toFixed(2));
  } else {
    const dateparts = month.split('-');
    const billYear = parseInt(dateparts[0], 10);
    const billMonth = parseInt(dateparts[1], 10);
    const sheet = new Map();
    const lastDay = lastDayOfMonth(new Date(billYear, billMonth, 0)).getDate();
    const dateToBill = new Date(billYear, billMonth-1, lastDay);
    const dailyRate = parseFloat((activeSubscription.monthlyPriceInDollars / lastDay).toFixed(3));
    users.forEach((user) => {
      const customerYear = user.activatedOn.getFullYear();
      const customerMonth = user.activatedOn.getMonth() + 1;
      const customerDay = user.activatedOn.getDate();
      let customerBillDay = lastDay;
      if (user.activatedOn.getTime() <= dateToBill.getTime()) {
          if (billYear === customerYear && billMonth === customerMonth) {
              // pro-rate it?
              customerBillDay = customerDay > 1 ? (lastDay - customerDay) : 1;
          }
        const tallysheet = sheet.get(month);
        if (!tallysheet) {
          sheet.set(month, { count: 1, total: customerBillDay * dailyRate});
        } else {
          sheet.set(month, { count: tallysheet.count+1, total: tallysheet.total+(customerBillDay * dailyRate)});
        }
      }
    });
    for(let entry of sheet.keys()) {
      const monthEntry = sheet.get(entry);
      monthTotal += monthEntry.total;
    }
  }
  return parseFloat(monthTotal.toFixed(2));
}

/*******************
* Helper functions *
*******************/

/**
  Takes a Date instance and returns a Date which is the first day
  of that month. For example:

  firstDayOfMonth(new Date(2019, 2, 7)) // => new Date(2019, 2, 1)

  Input type: Date
  Output type: Date
**/
function firstDayOfMonth(date) {
  return new Date(date.getFullYear(), date.getMonth(), 1)
}

/**
  Takes a Date object and returns a Date which is the last day
  of that month. For example:

  lastDayOfMonth(new Date(2019, 2, 7)) // => new Date(2019, 2, 28)

  Input type: Date
  Output type: Date
**/
function lastDayOfMonth(date) {
  return new Date(date.getFullYear(), date.getMonth() + 1, 0)
}

/**
  Takes a Date object and returns a Date which is the next day.
  For example:

  nextDay(new Date(2019, 2, 7))  // => new Date(2019, 2, 8)
  nextDay(new Date(2019, 2, 28)) // => new Date(2019, 3, 1)

  Input type: Date
  Output type: Date
**/
function nextDay(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1)
}

console.log('noUsers: ', billFor('2019-01', newPlan, noUsers));

console.log('constantUsers: ', billFor('2019-01', newPlan, constantUsers));

console.log('userSignedUp: ', billFor('2019-01', newPlan, userSignedUp));
