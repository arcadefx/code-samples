<?php
declare(strict_types = 1);

require('webhandler.php');
require('router/router.php');
require('controllers/users.php');

class RequestHandler extends WebHandler {
  public $route;
  public $value;
  public $permission;

  function __constructor() {
    $this->route = '';
    $this->value = null;
    $this->permission = '';
  }

  public function getDescription() {
    return 'a simple handler';
  }

  public function setPermission(string $permission) {
    // pretend middleware granted the user this permission
    $this->permission = $permission;
  }

  // put other useful methods here if needed
}

$request = new RequestHandler();
$request->setPermission('user'); // change to test permissions
list($request->route, $request->value) = $request->handleRequest();

// routes
$router->addRoute('/', $usersController, 'listUsers', [ 'user', 'editor' ]);
$router->addRoute('/user', $usersController, 'getUser', [ 'user', 'editor' ]);

try {
  $router->resolveRoute($request);
} catch (exception $e) {
  $request->sendResponse(['message' => "$e"]);
}
?>