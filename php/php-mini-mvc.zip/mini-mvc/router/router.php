<?php
    class Path {
        public $path_info;
        public $path_controller;
        public $path_method;
        public $path_permissions;
        function __construct(string $path, $controller = null, $method = null, $permissions = null) {
            $this->path_info = $path;
            $this->path_controller = $controller;
            $this->path_method = $method;
            $this->path_permissions = $permissions;
        }
    }

    class RouterHandler {
        private $paths;
        function __construct() {
            $this->paths = array();
        }

        public function addRoute(string $path = '', $controller = null, $method = null, $permissions = null) : int {
            $success = 0;
            if (strlen($path) > 0 && $controller !== null && $method !== null && $permissions !== null) {
                $success = 1;
                array_push($this->paths, new Path($path, $controller, $method, $permissions));
            }
            return $success;
        }

        // this handles simple endpoints, no hiearchy a/b/c/d/e
        public function resolveRoute($request = null) {
            if ($request == null) {
                throw new Exception('Request invalid!');
            } 
            foreach ($this->paths as $path) {
                if ($path->path_info === $request->route) {
                    if ($request->hasAuthorization($request->permission, $path->path_permissions)) {
                        call_user_func_array(array($path->path_controller, $path->path_method), array($request));
                    } else {
                        throw new Exception('Permission denied!');
                    }
                    break;
                }
            }
        }
    }

    $router = new RouterHandler();
?>