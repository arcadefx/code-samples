Code Challenge

How to run
----------

1. Extract the zip archive and go to the folder from the cli/console.
2. Use php7 and do: php -S localhost:8000

* Get all users
http://localhost:8000

* Get a specific user - John
http://localhost:8000/user/1

* Get a specific user - Mickey
http://localhost:8000/user/2

* Change permission by editing the index.php on line 32 and set the permission to another value

index.php is where it starts from
