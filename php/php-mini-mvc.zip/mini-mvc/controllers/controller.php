<?php
    require 'models/model.php';

    abstract class Controller {
        abstract protected function sendResponse($request, $data);
    }
?>