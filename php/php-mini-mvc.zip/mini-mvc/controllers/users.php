<?php
require 'controller.php';
require 'models/users.php';
require 'models/entries.php';

class UsersController extends Controller {

    private $models = array();

    function __construct($models = null) {
        $this->models = $models;
    }

    public function listUsers($request) {
        $rows = $this->models['usersModel']->read();
        $this->sendResponse($request, $rows);
    }

    public function getUser($request) {
        $value = $request->validateData('int', $request->value);
        $rows = $this->models['usersModel']->read($value);
        $this->hydrateEntries($rows);
        $this->sendResponse($request, $rows);
    }

    private function hydrateEntries(&$rows) {
        $entries = $this->models['entriesModel']->read(0, $rows['id']);
        if (count($entries)) {
            $rows['entries'] = $entries;
        }
    }

    public function sendResponse($request, $data) {
        // do anything prior to sending response
        $request->sendResponse($data);
    }
}

$usersController = new UsersController([ 
    'usersModel' => $usersModel,
    'entriesModel' => $entriesModel
]);
?>