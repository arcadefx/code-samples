<?php
    abstract class WebHandler {
        abstract protected function getDescription();
        abstract protected function setPermission(string $permission);
        
        public function handleRequest() : array {
            if ($this->getRequestType() === 'GET' || $this->getRequestType() === 'POST') {
              return $this->resolveEndPointWithValue();
            }
            return array();
        }
      
        // super simple api resolver -- a far better one can be made :)
        public function resolveEndPointWithValue() : array {
            $path = array_slice(explode('/', $_SERVER['REQUEST_URI']), 1);
            if (count($path) > 1) {
              $path[0] = trim('/'.filter_var($path[0], FILTER_SANITIZE_STRING));
              $path[1] = trim(filter_var($path[1], FILTER_SANITIZE_STRING));
	    } else {
	          $path[0] = '/';
              $path[1] = '';
	    }
            return $path;
        }

        public function getRequestType() : string {
            return $_SERVER['REQUEST_METHOD'];
        }

        public function hasAuthorization($user_permission, $permissions) : bool {
            return in_array($user_permission, $permissions);
        }

        public function validateData($type = 'string', $value = '') {
            // pretend to-do validation -- a JSON schema validation would be awesome.
            // https://github.com/justinrainbow/json-schema for example
            if ($type === 'int') {
                $value = (int) filter_var($value, FILTER_SANITIZE_NUMBER_INT);
            } else {
                $value = filter_var($value, FILTER_SANITIZE_STRING);;
            }
            return $value;
        }

        public function sendResponse($data = array()) {
            echo json_encode($data, JSON_FORCE_OBJECT);
            exit(0);
        }
    }
?>
