<?php
class EntryTypesModel extends Model {
    public function create(array $data) {
        // create a new entry type
    }

    public function read() {
        // read the table
    }

    public function update() {
        // update a row
    }

    public function delete() {
        // delete a row
    }
}

$entryTypesModel = new EntryTypesModel();
?>