<?php
class EntriesModel extends Model {

    private $fakeRows;
    function __construct() {
        $this->fakeRows = [
            [
                'id' => 1,
                'user_id' => 1,
                'title' => 'john entry title',
                'slug' => 'john entry slug'
            ],
            [
                'id' => 2,
                'user_id' => 1,
                'title' => 'john entry title 2',
                'slug' => 'john entry slug 2'
            ],
            [
                'id' => 3,
                'user_id' => 2,
                'title' => 'mickey entry title',
                'slug' => 'mickey entry slug'
            ],
            [
                'id' => 4,
                'user_id' => 2,
                'title' => 'mickey entry title 2',
                'slug' => 'mickey entry slug 2'
            ]
        ];
    }

    public function create(array $data) {
        // create a new entry type
    }

    public function read($id = 0, $userId = 0) {
        // read the table, skipping SQL query and assuming fetch occurred succesfully
        $result = array();
        if ($id > 0) {
            foreach( $this->fakeRows as $row ) {
                if ($row['id'] === $id) {
                    array_push($result, $row);
                    break;
                }
            }
        } else {
            foreach( $this->fakeRows as $row ) {
                if ($row['user_id'] === $userId) {
                    array_push($result, $row);
                }
            }
        }
        return $result;
    }

    public function update() {
        // update a row
    }

    public function delete() {
        // delete a row
    }
}

$entriesModel = new EntriesModel();
?>