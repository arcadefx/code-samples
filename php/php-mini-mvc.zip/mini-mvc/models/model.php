<?php
    // An ORM (object relation mapper) or PDO abstract could be used for models or RAW SQL
    class PDOfake {
        public function bindParam() {}
        public function execute() {
            return true;
        }
        public function fetch(int $recordId = 0, array $fakeRows) : array {
            $result = array();
            if ($recordId === 0) {
                $result = $fakeRows;
            } else {
                $result = $fakeRows[ $recordId-1 ];
            }
            return $result === null ? array() : $result;
        }
    }

    abstract class Model {
        abstract protected function create(array $data);
        abstract protected function read();
        abstract protected function update();
        abstract protected function delete();

        // PDO layer would be nice, but limited on time, so...
        public function prepare() {
            return new PDOfake(); // fake
        }
    }
?>