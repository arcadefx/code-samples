<?php
class UsersModel extends Model {

    private $fakeRows;
    function __construct() {
        $this->fakeRows = [
            [
                'id' => 1,
                'username' => 'john'
            ],
            [
                'id' => 2,
                'username' => 'mickey'
            ]
        ];
    }

    // create is fake
    public function create($data) {
        $stmt = $this->prepare("INSERT INTO users (COLUMNS_GO_HERE...) VALUES (:VALUE_NAMES_FOR_EACH)");        
        // bind all params, only one shown here
        $stmt->bindParam(':username', $username);

        // try to create
        try {
            $stmt->execute();
            return array('success' => 'user created');
        } catch (exception $e) {
            return array('failure' => "user not created $e");
        }
    }

    // method uses a fake PDO handler
    public function read(int $userId = 0) {
        $sql = 'SELECT id,username FROM users ORDER BY username';
        $rows = array();
        $recordId = 0; // get all users
        if ($userId > 0) {
            $recordId = $userId; // get only one record
            $sql = "SELECT id,username FROM users where id = ?";
        }
        $stmt = $this->prepare($sql);
        if ($stmt->execute(array($userId))) {
            $rows = $stmt->fetch($recordId, $this->fakeRows); // yah, normally you fetch each row, but this is fake :)
        }
        return $rows;
    }

    public function update(int $userId = 0) {
        // update a user
    }

    public function delete(int $userId = 0) {
        // delete a user
    }

}

$usersModel = new UsersModel();
?>